import { signUp, confirmSignUp, autoSignIn, signIn, signOut } from 'aws-amplify/auth';

/* async function handleSignUp({ email, password }) {
  try {
    const { nextStep } = await signUp({
      username: email,
      password,
      options: {
        userAttributes: {
          email,
        },
        autoSignIn: true
      }
    });
    console.log('Usuario registrado correctamente:', nextStep);
    return nextStep;
  } catch (error) {
    console.log('error signing up:', error);
  }
} */

  async function handleSignUp({ email, password }) {
    console.log('Datos enviados a signUp:', { username, email, password });
    try {
      const { nextStep } = await signUp({
        username: email,
        password,
        options: {
          userAttributes: {
            email,
          },
          
          autoSignIn: true 
        }
      });
  
      console.log('Usuario registrado correctamente:', nextStep);
      return nextStep;
      console.log(userId);
    } catch (error) {
      console.log('error signing up:', error);
    }
  }

async function handleSignUpConfirmation({ username, confirmationCode }) {
  // try {
  //   const { /*isSignUpComplete,*/ nextStep } = await confirmSignUp({
  //     username,
  //     confirmationCode
  //   });
  //   return nextStep;
  // } catch (error) {
  //   console.log('error confirming sign up', error);
  // }

  try {
    if (!email) {
      throw new Error('El campo de correo electrónico está vacío.');
    }
    if (!confirmationCode) {
      throw new Error('El código de confirmación está vacío.');
    }

    // Llama a confirmSignUp con el email como username
    console.log('Confirmando usuario con:', email, confirmationCode); // Verifica los valores
    await confirmSignUp(email, confirmationCode);
    alert('Cuenta confirmada, por favor inicia sesión.');
    setIsRegister(false);
    setIsConfirmationStep(false);
  } catch (error) {
    console.error('Error al confirmar el registro:', error);
    alert(`Error al confirmar el registro: ${error.message}`);
  }
}

async function handleAutoSignIn() {
  try {
    const signInOutput = await autoSignIn();
    return isSignedIn;
  } catch (error) {
    console.log(error);
  }
}


/* async function signIn({ email, password }) {
  try {
    const { isSignedIn, nextStep } = await signIn({ email, password });
  } catch (error) {
    console.log('error signing in', error);
  }
} */

  async function signIn({ email, password }) {
    try {
        // Cambiar el nombre del argumento 'email' a 'username'
        const { isSignedIn, nextStep } = await signIn({
            username: email, // Aquí pasamos email como username
            password,
        });
        console.log('Inicio de sesión exitoso:', isSignedIn, nextStep);
        return { isSignedIn, nextStep };
    } catch (error) {
        console.log('Error al iniciar sesión:', error);
        throw error; // Re-lanzar el error para manejarlo en el componente
    }
  }

async function handleSignOut() {
  try {
    await signOut();
  } catch (error) {
    console.log('error signing out: ', error);
  }
}