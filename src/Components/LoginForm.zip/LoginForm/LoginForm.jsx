/* import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './LoginForm.scss'
import Btn from '../Commons/Button/Button';
import Input from '../Commons/Inputs/Input';

const LoginForm = ({ descripcion }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    console.log('Email:', email)
    console.log('Password:', password)
    
    if (email && password) {
      navigate('/contenido-sesion')
    } else {
      alert('Por favor, completa todos los campos.')
    }
  };

  return (
    <form className='login__form' onSubmit={handleSubmit}>
      <h1>{descripcion}</h1>
      <section className='login__inputs'>
        <div className='login__email'>
          <label htmlFor="email">Correo Electrónico:</label>
          <Input
            type="email"
            name="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className='login__password'>
          <label htmlFor="password">Contraseña:</label>
          <Input
            type="password"
            name="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
      </section>

      <Btn
        type="submit"
        buttonDescription="Continuar"
        className="active"
      />
    </form>
  );
};

export default LoginForm;

 */


/************************************************+ */


import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './LoginForm.scss';
import Btn from '../Commons/Button/Button';
import Input from '../Commons/Inputs/Input';
import { signUp, confirmSignUp, signIn } from 'aws-amplify/auth';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isRegister, setIsRegister] = useState(false); // Alterna entre registro e inicio de sesión
  const [confirmationCode, setConfirmationCode] = useState('');
  const [isConfirmationStep, setIsConfirmationStep] = useState(false); // Maneja el paso de confirmación
  const navigate = useNavigate();

  // Manejar el registro
  const handleRegister = async () => {
    try {
      const result = await signUp({
        username: email, // Usa el correo como username
        password, // Contraseña
        attributes: { email }, // Configura el atributo email
        autoSignIn: { enabled: true }, // Intentar iniciar sesión automáticamente
      });
      console.log('Registro exitoso:', result);
      setIsConfirmationStep(true); // Cambia al paso de confirmación
    } catch (error) {
      console.error('Error en el registro:', error);
      alert(`Error en el registro: ${error.message}`);
    }
  };


  const handleConfirmation = async () => {
    debugger; // Pausa aquí para inspeccionar el flujo
    try {
      if (!email) {
        throw new Error('El campo de correo electrónico está vacío.');
      }
      if (!confirmationCode) {
        throw new Error('El código de confirmación está vacío.');
      }
  
      console.log('Valores enviados a confirmSignUp:', { email, confirmationCode });
      if (!email || !confirmationCode) {
        console.error('Email o código de confirmación inválidos');
        return;
      }
      await confirmSignUp(email, confirmationCode);
      alert('Cuenta confirmada, por favor inicia sesión.');
      setIsRegister(false);
      setIsConfirmationStep(false);
    } catch (error) {
      console.error('Error al confirmar el registro:', error);
      alert(`Error al confirmar el registro: ${error.message}`);
    }
  };  
  
  


  // Manejar inicio de sesión
  const handleLogin = async () => {
    try {
      const result = await signIn(email, password);
      console.log('Inicio de sesión exitoso:', result);
      navigate('/contenido-sesion'); // Redirige al contenido
    } catch (error) {
      console.error('Error al iniciar sesión:', error);
      alert(`Error al iniciar sesión: ${error.message}`);
    }
  };



  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log('handleSubmit ejecutado', { isConfirmationStep, isRegister });
  
    if (isConfirmationStep) {
      // Paso de confirmación
      handleConfirmation();
    } else if (isRegister) {
      // Registro de usuario
      handleRegister();
    } else {
      // Inicio de sesión
      handleLogin();
    }
  };
  


  return (
    <form className="login__form" onSubmit={handleSubmit}>
      <h1>{isRegister ? 'Registrar Usuario' : 'Iniciar Sesión'}</h1>
      <section className="login__inputs">
        <div className="login__email">
          <label htmlFor="email">Correo Electrónico:</label>
          <Input
            type="email"
            name="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        {!isConfirmationStep && (
          <div className="login__password">
            <label htmlFor="password">Contraseña:</label>
            <Input
              type="password"
              name="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
        )}
        {isConfirmationStep && (
          <div className="login__confirmation">
            <label htmlFor="confirmationCode">Código de Confirmación:</label>
            <Input
              type="text"
              name="confirmationCode"
              id="confirmationCode"
              value={confirmationCode}
              onChange={(e) => setConfirmationCode(e.target.value)}
            />
          </div>
        )}
      </section>

      <Btn
        type="submit"
        buttonDescription={isConfirmationStep ? 'Confirmar' : isRegister ? 'Registrar' : 'Iniciar Sesión'}
        className="active"
      />

      <div className="login__toggle">
        {isRegister ? (
          <p>
            ¿Ya tienes una cuenta?{' '}
            <a href="#" onClick={() => setIsRegister(false)}>
              Inicia sesión
            </a>
          </p>
        ) : (
          <p>
            ¿No tienes una cuenta?{' '}
            <a href="#" onClick={() => setIsRegister(true)}>
              Regístrate
            </a>
          </p>
        )}
      </div>
    </form>
  );
};

export default LoginForm;



